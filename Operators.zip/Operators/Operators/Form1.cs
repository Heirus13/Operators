﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Operators
{
    public partial class Form1 : Form
    {
        
        double result = 0.0;
        string[] operand;
        double num = 0.0;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            string input = txtEnter.Text;
            try
            {
                ScanData(out operand, out num);
                DoNextOperation(operand, num);
            }
            catch(FormatException)
            {
                MessageBox.Show("Invalid input", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }
        public void ScanData(out string[] operand, out double num)
        {
            num = Convert.ToDouble(txtEnter.Text.Substring(1));
            operand = txtEnter.Text.Split(' ');
        }
        public void DoNextOperation(string[] operand, double num)
        {
            switch (operand[0])
                {
                    case "+":
                        result += num;
                    lblResult.Text = "the result so far is " + result.ToString("0.0");
                    break;
                    case "-":
                        result -= num;
                    lblResult.Text = "the result so far is " + result.ToString("0.0");
                    break;
                    case "*":
                        result *= num;
                    lblResult.Text = $"the result so far is {result}.";
                    break;
                    case "/":
                        result /= num;
                    lblResult.Text = "the result so far is " + result.ToString("");
                    break;
                    case "^":
                        result = Math.Pow(result, num);
                    lblResult.Text = $"the result so far is {result}.";
                    break;
                    case "q":
                    lblResult.Text = "Final result is " + result.ToString("0.0"); 
                    break;
                default:
                        MessageBox.Show("Invalid input", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }
            
        }
    }
}
